$(document).ready(function(){
	$('.header').height($(window).height());
})
$('.carousel').carousel({
	interval: 2000
  })