<?php
    $host="localhost";
    $user="root";
    $mdp="";
?>
